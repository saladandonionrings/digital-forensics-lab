from Crypto.Cipher import AES

# Données extraites de votre analyse précédente
key = b"sup3r_s3cr3t_k3y"
ct_hex = "4d34436abd7fee3c371e617f3e4e5be0f200f98cf6d3499db63090940f445509faf701e09643491d3a97da79d3397752"

# Initialisation
cipher = AES.new(key, AES.MODE_ECB)

# Déchiffrement sécurisé
decrypted = cipher.decrypt(bytes.fromhex(ct_hex))

print("Résultat du déchiffrement :")
print(decrypted.decode(errors='ignore'))